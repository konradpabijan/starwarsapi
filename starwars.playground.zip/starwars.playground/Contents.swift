//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

func fetchResultsFromApi() {
    
struct StarWarsPeople: Codable {
    let name: String?
    let height: Int?
    let mass: Int?
    let hair_color: String?
    let homeworld: URL?
    
    private enum CodingKeys: String, CodingKey {
        case name
        case height
        case mass
        case hair_color
        case homeworld
}
    }

    guard let swUrl = URL(string: "https://swapi.co/api/people/1/?format=json") else { return }
URLSession.shared.dataTask(with: swUrl) { (data, response
    , error) in
    guard let data = data else { return }
    do {
        let decoder = JSONDecoder()
        let person = try decoder.decode(StarWarsPeople.self, from: data)
        print(person.name ?? "dupa")
        print(person.height ?? "test")
        
        
    } catch let err {
        print("Err", err)
    }
    }.resume()
}
fetchResultsFromApi()

